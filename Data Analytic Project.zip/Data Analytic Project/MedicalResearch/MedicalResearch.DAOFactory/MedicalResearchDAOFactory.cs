﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MedicalResearch.Entities;
using MedicalResearch.Utilities;
using MedicalResearch.DataAccessLayer;

namespace MedicalResearch.DAOFactory
{
    public  class MedicalResearchDAOFactory
    {

        private MedicalResearchDAOFactory medicalResearchDAOFactoryObj = null;


        public MedicalResearchDAOFactory CreateMedicalResearchDAOFactoryObj()
        {
              medicalResearchDAOFactoryObj=new MedicalResearchDAOFactory();

              return medicalResearchDAOFactoryObj;
        }

        public IDiseasesDAO CreateDiseaseDAO()
        {
            IDiseasesDAO diseaseDAOObj = new DiseasesDAO();
            return diseaseDAOObj;
        }

        public ISymptomsDAO CreateSymptomsDAO()
        {
            ISymptomsDAO symptomsDAOObj = new SymptomsDAO();
            return symptomsDAOObj;
        }

        public IDiagnoseDAO CreateDiagnoseDAO()
        {
            IDiagnoseDAO DiagnoseDAOObj = new DiagnoseDAO();
            return DiagnoseDAOObj;
        }


    }
}
