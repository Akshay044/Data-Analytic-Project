﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MedicalResearch.DAOFactory;
using MedicalResearch.DataAccessLayer;
using MedicalResearch.Utilities;
using MedicalResearch.Entities;


namespace MedicalResearch.BusinessLayer
{
    public class DiagnoseManager:IDiagnoseManager
    {
        
   
        private IDiagnoseDAO diagnoseDAO;

        public DiagnoseManager()
        {
            MedicalResearchDAOFactory medicalResearchDAOFactoryObj = new MedicalResearchDAOFactory().CreateMedicalResearchDAOFactoryObj();
            diagnoseDAO = medicalResearchDAOFactoryObj.CreateDiagnoseDAO();


        }
        public List<DiagnoseDetails> RetrieveDiagnoseResults(List<string> listOfSymptoms)
        {
            try
            {
                return diagnoseDAO.RetrieveDiagnoseResults(listOfSymptoms);
            }


            catch (MedicalResearchBusinessLayerException bLEx)
            {

                throw bLEx;
            }


            catch (MedicalResearchDALException dALEx)
            {
                MedicalResearchBusinessLayerException bLEx = new MedicalResearchBusinessLayerException(dALEx.Message,dALEx.InnerException);
                throw bLEx;
            }

            catch (Exception ex)
            {
                MedicalResearchBusinessLayerException bLEx = new MedicalResearchBusinessLayerException(ex.Message, ex.InnerException);
                throw bLEx;
            }
           
        }
    }
}
