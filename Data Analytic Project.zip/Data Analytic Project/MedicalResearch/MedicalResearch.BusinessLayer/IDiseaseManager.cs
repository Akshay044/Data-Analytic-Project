﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MedicalResearch.DAOFactory;
using MedicalResearch.Entities;

namespace MedicalResearch.BusinessLayer
{
   public interface IDiseaseManager
    {

        bool AddDiseaseDetails(DiseaseDetails diseaseDetails);
        List<DiseaseDetails> GetAllDiseases();
    }
}
