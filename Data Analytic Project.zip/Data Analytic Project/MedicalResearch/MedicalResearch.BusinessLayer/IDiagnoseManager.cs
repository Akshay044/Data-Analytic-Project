﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MedicalResearch.Entities;

namespace MedicalResearch.BusinessLayer
{
  public  interface IDiagnoseManager
    {

       List<DiagnoseDetails> RetrieveDiagnoseResults(List<string> listOfSymptoms);
    }
}
