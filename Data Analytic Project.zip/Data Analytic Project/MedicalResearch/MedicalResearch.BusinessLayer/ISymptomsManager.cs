﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MedicalResearch.Entities;
using MedicalResearch.DAOFactory;

namespace MedicalResearch.BusinessLayer
{
   public interface ISymptomsManager
    {
        bool AddSymptomToDisease(SymptomDetails symptomDetails);
        List<string> RetrieveUniqueSymptoms();

    }
}
