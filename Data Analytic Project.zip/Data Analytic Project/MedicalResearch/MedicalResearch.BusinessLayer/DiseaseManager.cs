﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MedicalResearch.Entities;
using MedicalResearch.DAOFactory;
using MedicalResearch.DataAccessLayer;
using MedicalResearch.Utilities;

namespace MedicalResearch.BusinessLayer
{
    public class DiseaseManager:IDiseaseManager
    {

        private IDiseasesDAO diseaseDAO;

        public DiseaseManager()
        {
            MedicalResearchDAOFactory medicalResearchDAOFactoryObj = new MedicalResearchDAOFactory().CreateMedicalResearchDAOFactoryObj();
            diseaseDAO = medicalResearchDAOFactoryObj.CreateDiseaseDAO();
        }
        public bool AddDiseaseDetails(DiseaseDetails diseaseDetails)
        {
            try
            {
                return diseaseDAO.AddDiseaseDetails(diseaseDetails);
            }

            catch (MedicalResearchBusinessLayerException bLEx)
            {

                throw bLEx;
            }


            catch (MedicalResearchDALException dALEx)
            {
                MedicalResearchBusinessLayerException bLEx = new MedicalResearchBusinessLayerException(dALEx.Message, dALEx.InnerException);
                throw bLEx;
            }

            catch (Exception ex)
            {
                MedicalResearchBusinessLayerException bLEx = new MedicalResearchBusinessLayerException(ex.Message, ex.InnerException);
                throw bLEx;
            }

        }

             public List<DiseaseDetails> GetAllDiseases()
             {
                 try
                 {
                     return diseaseDAO.GetAllDiseases();
                 }

                 catch (MedicalResearchBusinessLayerException bLEx)
                 {

                     throw bLEx;
                 }


                 catch (MedicalResearchDALException dALEx)
                 {
                     MedicalResearchBusinessLayerException bLEx = new MedicalResearchBusinessLayerException(dALEx.Message, dALEx.InnerException);
                     throw bLEx;
                 }

                 catch (Exception ex)
                 {
                     MedicalResearchBusinessLayerException bLEx = new MedicalResearchBusinessLayerException(ex.Message, ex.InnerException);
                     throw bLEx;
                 }
             }




           
    }
}
