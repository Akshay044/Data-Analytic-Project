﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MedicalResearch.Entities;
using MedicalResearch.DAOFactory;
using MedicalResearch.DataAccessLayer;
using MedicalResearch.Utilities;

namespace MedicalResearch.BusinessLayer
{
  public  class SymptomsManager:ISymptomsManager
    {
      private ISymptomsDAO symptomsDAO;


      public SymptomsManager()
      {
          MedicalResearchDAOFactory medicalResearchDAOFactoryObj = new MedicalResearchDAOFactory().CreateMedicalResearchDAOFactoryObj();

          symptomsDAO = medicalResearchDAOFactoryObj.CreateSymptomsDAO();
      }

        public bool AddSymptomToDisease(Entities.SymptomDetails symptomDetails)
        {

            try
            {
                return symptomsDAO.AddSymptomToDisease(symptomDetails);
            }
            catch (MedicalResearchBusinessLayerException bLEx)
            {

                throw bLEx;
            }


            catch (MedicalResearchDALException dALEx)
            {
                MedicalResearchBusinessLayerException bLEx = new MedicalResearchBusinessLayerException(dALEx.Message, dALEx.InnerException);
                throw bLEx;
            }

            catch (Exception ex)
            {
                MedicalResearchBusinessLayerException bLEx = new MedicalResearchBusinessLayerException(ex.Message, ex.InnerException);
                throw bLEx;
            }
         
        }

        public List<string> RetrieveUniqueSymptoms()
        {

            try
            {
                return symptomsDAO.RetrieveUniqueSymptoms();
            }
            catch (MedicalResearchBusinessLayerException bLEx)
            {

                throw bLEx;
            }


            catch (MedicalResearchDALException dALEx)
            {
                MedicalResearchBusinessLayerException bLEx = new MedicalResearchBusinessLayerException(dALEx.Message, dALEx.InnerException);
                throw bLEx;
            }

            catch (Exception ex)
            {
                MedicalResearchBusinessLayerException bLEx = new MedicalResearchBusinessLayerException(ex.Message, ex.InnerException);
                throw bLEx;
            }

        }
    }

}
