﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using MedicalResearch.DAOFactory;
using MedicalResearch.Entities;
using MedicalResearch.ServiceLayer;

using System.ServiceModel;

namespace MedicalResearch.WebLayer
{
    public partial class AddDiseaseDetails : System.Web.UI.Page
    {
      
        public static ServiceReference1.MedicalResearchServiceClient medicalResearchClient = new ServiceReference1.MedicalResearchServiceClient();

     
        
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
               
            }
        }

        protected void Button1_Click(object sender, EventArgs e)
        {

            try
            {
                string severity = null;
                if (rdBtnHigh.Checked == true)
                {
                    severity = "high";
                }

                if (rdBtnLow.Checked == true)
                {
                    severity = "low";
                }

                if (rdBtnMedium.Checked == true)
                {
                    severity = "medium";
                }

                if (txtBoxName.Text=="")
                {
                    lblError.Text = "The value provided for the NAME field is incorrect or incomplete";
                }
               
               else if (ddlSeverity.SelectedValue=="--Select--")
                {
                    lblError.Text = "Please select a cause from the drop down list";
                }


                else
                {
             
                  
                   
                    DiseaseDetails disease = new DiseaseDetails()
                    {
                        DiseaseName = txtBoxName.Text,
                        Description = txtBoxDescription.Text,
                        Cuase = ddlSeverity.Text,
                        Severity = severity

                    };

                    medicalResearchClient.AddDiseaseDetails(disease);
                    Response.Redirect("Home.aspx?query=The details of the new disease have been saved successfully");
                   
                }
              
            }
            catch (FaultException<MRServiceError> faulEx)
            {
                lblError.ForeColor = System.Drawing.Color.Red;
                lblError.Text = faulEx.InnerException.Message;

            }

            catch (Exception ex)
            {
                lblError.ForeColor = System.Drawing.Color.Red;
                lblError.Text = ex.InnerException.Message;

            } 




        }
    }
}