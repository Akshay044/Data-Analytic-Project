﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.ServiceModel;
using MedicalResearch.ServiceLayer;
using MedicalResearch.Entities;

namespace MedicalResearch.WebLayer
{
    public partial class AddSymptoms : System.Web.UI.Page
    {

        public static ServiceReference1.MedicalResearchServiceClient medicalResearchServiceObj = new ServiceReference1.MedicalResearchServiceClient();

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                try
                {
                 
                    ddlDieases.DataSource = medicalResearchServiceObj.GetAllDiseases().ToList<DiseaseDetails>();
                    ddlDieases.DataTextField = "DiseaseName";
                    ddlDieases.DataValueField = "DiseaseId";
                    ddlDieases.DataBind();
                }
                catch (FaultException<MRServiceError> faultEx)
                {

                    lblError.Text = faultEx.InnerException.Message;
                }
                catch (Exception ex)
                {
                    lblError.Text = ex.InnerException.Message;
                }

            }
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                if( txtBoxSymptom.Text=="")
                {
                    lblError.Text = "Enter the severity in the text box";
                }

                else if (ddlDieases.SelectedValue == "--Select Disease--")
                {
                    lblError.Text = "Select a disease from the list";
                }

                else
                {
                  SymptomDetails symptomDetails=new SymptomDetails()
                  {
                      SymptomName=txtBoxSymptom.Text,
                      DiseaseId=Convert.ToInt32(ddlDieases.SelectedItem.Value),
                      Description=txtBoxDescription.Text,
                     

                  };

                  medicalResearchServiceObj.AddSymptomToDisease(symptomDetails); 
                }


            }
            catch (FaultException<MRServiceError> faultEx)
            {
                lblError.Text = faultEx.InnerException.Message;

            }

            catch (Exception ex)
            {
                lblError.Text = ex.InnerException.Message;

            }
        }
    }
}