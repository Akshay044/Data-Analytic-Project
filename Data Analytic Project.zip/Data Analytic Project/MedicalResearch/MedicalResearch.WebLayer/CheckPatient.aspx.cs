﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace MedicalResearch.WebLayer
{
    public partial class CheckPatient : System.Web.UI.Page
    {

        ServiceReference1.MedicalResearchServiceClient medicalResearchService = new ServiceReference1.MedicalResearchServiceClient();
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {

             ListBox1.DataSource = medicalResearchService.RetrieveUniqueSymptoms();
             ListBox1.DataBind();

            }

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
          int[] array=ListBox1.GetSelectedIndices();
          List<string> listOfSymptoms = new List<string>();
          for (int i = 0; i < array.Length; i++)
          {
            string symptom= ListBox1.Items[array[i]].Text;
            listOfSymptoms.Add(symptom);
        
              
          }
          List<Entities.DiagnoseDetails> diagDetails = medicalResearchService.RetrieveDiagnoseResults(listOfSymptoms.ToArray()).ToList();
          GridView1.DataSource = diagDetails;
          GridView1.DataBind();
          
        }

      

    }
}