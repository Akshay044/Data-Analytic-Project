﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MedicalResearch.BusinessLayer;

namespace MedicalResearch.BusinessFactory
{
    public class MedicalResearchBusinessFactory
    {
        private MedicalResearchBusinessFactory medicalResearchBusinessFactoryObj = null;


        public MedicalResearchBusinessFactory CreateMedicalResearchDAOFactoryObj()
        {
            medicalResearchBusinessFactoryObj = new MedicalResearchBusinessFactory();

            return medicalResearchBusinessFactoryObj;
        }


        public IDiseaseManager CreateDiseaseManager()
        {
            IDiseaseManager diseaseManagerObj = new DiseaseManager();
            return diseaseManagerObj;
        }

        public ISymptomsManager CreateSymptomsManager()
        {
            ISymptomsManager symptomsManagerObj = new SymptomsManager();
            return symptomsManagerObj;
        }

        public IDiagnoseManager CreateDiagnoseDAO()
        {
            IDiagnoseManager DiagnoseManagerObj = new DiagnoseManager();
            return DiagnoseManagerObj;
        }






    }
}
