﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MedicalResearch.Utilities
{
   public class MedicalResearchDALException:ApplicationException
    {
        public MedicalResearchDALException()
       {

           ErrorLogger.LogError("Some error occured",null);

       }


      public MedicalResearchDALException(string errorMessage):base(errorMessage)
      {

          ErrorLogger.LogError(errorMessage, null);

      }


      public MedicalResearchDALException(string errorMessage, Exception innerException)
          : base(errorMessage, innerException)
      {

          ErrorLogger.LogError(errorMessage, innerException);


      }
    }
}
