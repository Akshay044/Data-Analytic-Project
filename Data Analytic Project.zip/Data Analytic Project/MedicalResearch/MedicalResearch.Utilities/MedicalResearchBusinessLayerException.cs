﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MedicalResearch.Utilities
{
   public class MedicalResearchBusinessLayerException:ApplicationException
    {

      public MedicalResearchBusinessLayerException()
       {

           ErrorLogger.LogError("Some error occured",null);

       }


      public MedicalResearchBusinessLayerException(string errorMessage):base(errorMessage)
      {

          ErrorLogger.LogError(errorMessage, null);

      }                                                                                            


      public MedicalResearchBusinessLayerException(string errorMessage, Exception innerException)
          : base(errorMessage, innerException)
      {

          ErrorLogger.LogError(errorMessage, innerException);


      }

    }



}
