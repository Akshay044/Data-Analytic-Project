﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;

namespace MedicalResearch.Utilities
{
   internal static class ErrorLogger
    {
       private static StreamWriter writer;

       public static void LogError(string errorMessage, Exception innerException)
       {

           using (writer=new StreamWriter(@"c:\users\m1023130\documents\visual studio 2010\Projects\MedicalResearch\ErrorLog.txt",true))
           {
               if (writer!=null)
               {
                   if (errorMessage==null)
                   {
                       writer.WriteLine("Error Message not found");
                   }
                   else
                   {
                       writer.WriteLine(errorMessage);
                   }

                   if (innerException==null)
                   {
                       writer.WriteLine("Inner exception not found");
                       
                   }
                   else
                   {
                       writer.WriteLine(innerException);
                   }

               }




           }


       }


    }
}
