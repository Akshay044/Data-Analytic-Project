﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

using MedicalResearch.Utilities;
using MedicalResearch.BusinessLayer;
using MedicalResearch.BusinessFactory;
using MedicalResearch.Entities;

namespace MedicalResearch.ServiceLayer
{
    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    public class MedicalResearchService : IMedicalResearchService
    {
        IDiseaseManager diseaseManager;
        ISymptomsManager symptomsManager;
        IDiagnoseManager diagnoseManager;

        public MedicalResearchService()
        {
            MedicalResearchBusinessFactory medicalResearchBusinessFactoryObj = new MedicalResearchBusinessFactory().CreateMedicalResearchDAOFactoryObj();
            diseaseManager = medicalResearchBusinessFactoryObj.CreateDiseaseManager();
            symptomsManager = medicalResearchBusinessFactoryObj.CreateSymptomsManager();
            diagnoseManager=  medicalResearchBusinessFactoryObj.CreateDiagnoseDAO();

        }


        public bool AddDiseaseDetails(DiseaseDetails diseaseDetails)
        {
            bool diseaseAddedStatus = false; 
            try
            {
                diseaseManager.AddDiseaseDetails(diseaseDetails);
                
                diseaseAddedStatus = true;
            }
            catch (MedicalResearchBusinessLayerException bLEx)
            {
                MRServiceError medicalResearchServiceError = new MRServiceError() { errorMessage = bLEx.ToString() };
                FaultException<MRServiceError> faultEx = new FaultException<MRServiceError>(medicalResearchServiceError, new FaultReason(medicalResearchServiceError.errorMessage));

                throw faultEx;
            }                                                         

            catch (Exception ex)
            {
                MRServiceError medicalResearchServiceError = new MRServiceError() { errorMessage = ex.ToString() };
                FaultException<MRServiceError> faultEx = new FaultException<MRServiceError>(medicalResearchServiceError, new FaultReason(medicalResearchServiceError.errorMessage));
                throw faultEx;
            }

            return diseaseAddedStatus;
            
        }

        public List<DiseaseDetails> GetAllDiseases()
        {
            try
            {
               return diseaseManager.GetAllDiseases();
            }
            catch (MedicalResearchBusinessLayerException bLEx)
            {
                MRServiceError medicalResearchServiceError = new MRServiceError() { errorMessage = bLEx.ToString() };
                FaultException<MRServiceError> faultEx = new FaultException<MRServiceError>(medicalResearchServiceError, new FaultReason(medicalResearchServiceError.errorMessage));

                throw faultEx;
            }

            catch (Exception ex)
            {
                MRServiceError medicalResearchServiceError = new MRServiceError() { errorMessage = ex.ToString() };
                FaultException<MRServiceError> faultEx = new FaultException<MRServiceError>(medicalResearchServiceError, new FaultReason(medicalResearchServiceError.errorMessage));
                throw faultEx;
            }
        }

        public bool AddSymptomToDisease(SymptomDetails symptomDetails)
        {
            bool symptomsAddedStatus = false;
            try
            {
                symptomsManager.AddSymptomToDisease(symptomDetails);
                symptomsAddedStatus = true;
               
            }
            catch (MedicalResearchBusinessLayerException bLEx)
            {
                MRServiceError medicalResearchServiceError = new MRServiceError() { errorMessage = bLEx.ToString() };
                FaultException<MRServiceError> faultEx = new FaultException<MRServiceError>(medicalResearchServiceError, new FaultReason(medicalResearchServiceError.errorMessage));
                throw faultEx;
            }

            catch (Exception ex)
            {
                MRServiceError medicalResearchServiceError = new MRServiceError() { errorMessage = ex.ToString() };
                FaultException<MRServiceError> faultEx = new FaultException<MRServiceError>(medicalResearchServiceError, new FaultReason(medicalResearchServiceError.errorMessage));
                throw faultEx;
            }

            return symptomsAddedStatus;
        }


        public  List<string> RetrieveUniqueSymptoms()
        {
            try
            {
              return  symptomsManager.RetrieveUniqueSymptoms();
            }
            catch (MedicalResearchBusinessLayerException bLEx)
            {
                MRServiceError medicalResearchServiceError = new MRServiceError() { errorMessage = bLEx.ToString() };
                FaultException<MRServiceError> faultEx = new FaultException<MRServiceError>(medicalResearchServiceError, new FaultReason(medicalResearchServiceError.errorMessage));
                throw faultEx;
            }

            catch (Exception ex)
            {
                MRServiceError medicalResearchServiceError = new MRServiceError() {errorMessage=ex.ToString() };
                FaultException<MRServiceError> faultEx = new FaultException<MRServiceError>(medicalResearchServiceError, new FaultReason(medicalResearchServiceError.errorMessage));
                throw faultEx;

            }
        }

        public List<DiagnoseDetails> RetrieveDiagnoseResults(List<string> listOfSymptoms)
        {
            try
            {
                return diagnoseManager.RetrieveDiagnoseResults(listOfSymptoms);
            }

            catch (MedicalResearchBusinessLayerException bLEx)
            {
                MRServiceError medicalResearchServiceError = new MRServiceError() {errorMessage=bLEx.ToString() };
                FaultException<MRServiceError> faultEx = new FaultException<MRServiceError>(medicalResearchServiceError, new FaultReason(medicalResearchServiceError.errorMessage));
                throw faultEx;

            }
            catch (Exception ex)
            {

                MRServiceError medicalResearchServiceError = new MRServiceError() { errorMessage = ex.ToString() };
                FaultException<MRServiceError> faultEx = new FaultException<MRServiceError>(medicalResearchServiceError, new FaultReason(medicalResearchServiceError.errorMessage));
                throw faultEx;
            }
        }
    }
}
