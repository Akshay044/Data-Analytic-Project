﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Data.Entity;
using System.Runtime.Serialization;


namespace MedicalResearch.Entities
{
    [DataContract]
    public class DiseaseDetails
    {

        [DataMember]
        public int DiseaseId { get; set; }
        

        [DataMember]
        public string DiseaseName { get; set; }

        [DataMember]
        public string Severity { get; set; }

        [DataMember]
        public string Cuase { get; set; }

        [DataMember]
        public string Description { get; set; }


    }
}
