﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MedicalResearch.Entities
{
    
    [DataContract]
   public class DiagnoseDetails
    {
        [DataMember]
        public string DiseaseName { get; set; }

        [DataMember]
        public string Severity { get; set; }

         [DataMember]
        public string Symptoms { get; set; }


    }
}
