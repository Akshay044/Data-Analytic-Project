﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MedicalResearch.Entities
{

   [DataContract]
   public class SymptomDetails
    {

       [DataMember]
        public int SymptomId { get; set; }

       [DataMember]
       public int DiseaseId { get; set; }

       [DataMember]
       public string SymptomName { get; set; }

       [DataMember]
       public string Description { get; set; }





    }
}
