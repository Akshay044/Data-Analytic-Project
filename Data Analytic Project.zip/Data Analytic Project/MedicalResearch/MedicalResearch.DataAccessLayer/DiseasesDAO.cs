﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data.SqlClient;
using MedicalResearch.Entities;
using MedicalResearch.Utilities;

namespace MedicalResearch.DataAccessLayer
{
    public class DiseasesDAO:IDiseasesDAO
    {


        public bool AddDiseaseDetails(DiseaseDetails diseaseDetails)
        {
            bool diseaseAddedStatus = false;
            DiseaseDetail diseaseDetailsTblData;

            try
            {
                diseaseDetailsTblData = ConvertDiseaseDetailEntityToTable(diseaseDetails);
                using (MedicalResearchEntities medicalResearchDB = new MedicalResearchEntities())
                {

                    if (medicalResearchDB != null)
                    {
                        medicalResearchDB.AddToDiseaseDetails(diseaseDetailsTblData);
                        medicalResearchDB.SaveChanges();
                        diseaseAddedStatus = true;
                    }
                    else
                    {
                        diseaseAddedStatus = false;
                        throw new MedicalResearchDALException("No tables found in the Medical Research database");

                    }


                }

                return diseaseAddedStatus;

            }

            catch (MedicalResearchDALException dalEx)
            {
               
                throw dalEx;


            }

            catch (SqlException sqlEx)
            {
                MedicalResearchDALException dalEx = new MedicalResearchDALException(sqlEx.Message, sqlEx.InnerException);
                throw dalEx;
                

            }
            catch (Exception ex)
            {

                MedicalResearchDALException Dalex = new MedicalResearchDALException(ex.Message, ex.InnerException);
                throw Dalex;
                
            }
           

        }


         public List<DiseaseDetails> GetAllDiseases()
        {

            List<DiseaseDetails> listOfEntityDiseaseDetails=new List<DiseaseDetails>();
            try
            {
                using ( MedicalResearchEntities medicalResearchDB = new MedicalResearchEntities())
                {
                 var listIOfDiseaseDetails= medicalResearchDB.GetAllDiseases();


                 foreach (var disease in listIOfDiseaseDetails)
                 {
                    
                   
                     listOfEntityDiseaseDetails.Add(ConvertDiseaseDetailTableToTEntity(disease));

                 }
                }

                return listOfEntityDiseaseDetails;
           
            }

                catch (MedicalResearchDALException dalEx)
            {
               
                throw dalEx;


            }

            catch (SqlException sqlEx)
            {
                MedicalResearchDALException dalEx = new MedicalResearchDALException(sqlEx.Message, sqlEx.InnerException);
                throw dalEx;
                

            }
            catch (Exception ex)
            {

                MedicalResearchDALException Dalex = new MedicalResearchDALException(ex.Message, ex.InnerException);
                throw Dalex;
                
            }



             
         }

        #region Helper Methods

        private DiseaseDetail ConvertDiseaseDetailEntityToTable(DiseaseDetails diseaseDetails)
        {

            DiseaseDetail diseaseDetailsTbl = new DiseaseDetail()
            {
                DiseaseName = diseaseDetails.DiseaseName,
                Severity = diseaseDetails.Severity,
                Cause = diseaseDetails.Cuase,
                Description = diseaseDetails.Description



            };

            return diseaseDetailsTbl;

        }


           private DiseaseDetails  ConvertDiseaseDetailTableToTEntity(DiseaseDetail diseaseDetailsTbl)
        {

            DiseaseDetails diseaseDetailsEntityObj = new DiseaseDetails()
            {
                DiseaseId=diseaseDetailsTbl.DiseaseId,
                DiseaseName = diseaseDetailsTbl.DiseaseName,
                Severity = diseaseDetailsTbl.Severity,
                Cuase = diseaseDetailsTbl.Cause,
                Description = diseaseDetailsTbl.Description



            };

            return diseaseDetailsEntityObj;

        }


        #endregion


    }

}
