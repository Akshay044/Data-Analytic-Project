﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MedicalResearch.Entities;
using MedicalResearch.Utilities;
using System.Data.SqlClient;

namespace MedicalResearch.DataAccessLayer
{
   public class DiagnoseDAO : IDiagnoseDAO
    {
       public List<DiagnoseDetails> RetrieveDiagnoseResults(List<string> listOfSymptoms)
        {
            try
            {
                List<DiagnoseDetails> listOfDiagnosticDetails=new List<DiagnoseDetails>();

                using (MedicalResearchEntities medicalResearchDB=new MedicalResearchEntities())
                {
                    
           foreach (var symtomName in listOfSymptoms)
	       {
               var diseases = (from symptom in medicalResearchDB.SymptomsDetails select symptom).Where(x => x.SymptomName == symtomName).Select(y => new { symtomName = y.SymptomName, diseaseId = y.DiseaseId });

              

               foreach (var dis in diseases)
	        {
		 
	      
               DiagnoseDetails diseaseDetails = new DiagnoseDetails()
               {
                 DiseaseName=(from disease in medicalResearchDB.DiseaseDetails select disease).Where(x=>x.DiseaseId==dis.diseaseId).Select(y=>y.DiseaseName).FirstOrDefault(),
                 Severity= (from disease in medicalResearchDB.DiseaseDetails select disease).Where(x=>x.DiseaseId==dis.diseaseId).Select(y=>y.Severity).FirstOrDefault(),
                 Symptoms=dis.symtomName
               };

               listOfDiagnosticDetails.Add(diseaseDetails);
              
             }
   
            
	      
           }
                  
                    
                }

                return listOfDiagnosticDetails;
            }
            catch (MedicalResearchDALException dalEx)
            {

                throw dalEx;


            }

            catch (SqlException sqlEx)
            {
                MedicalResearchDALException dalEx = new MedicalResearchDALException(sqlEx.Message, sqlEx.InnerException);
                throw dalEx;


            }
            catch (Exception ex)
            {

                MedicalResearchDALException Dalex = new MedicalResearchDALException(ex.Message, ex.InnerException);
                throw Dalex;

            }
        }



        #region Helper Methods

        //private  ConvertDiseaseDetailEntityToTable(DiseaseDetails diseaseDetails)
        //{


        //}

        #endregion
    }
}
