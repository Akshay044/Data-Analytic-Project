﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MedicalResearch.Entities;
using MedicalResearch.Utilities;

namespace MedicalResearch.DataAccessLayer
{
   public interface ISymptomsDAO
    {

         bool AddSymptomToDisease(SymptomDetails symptomDetails);
         List<string> RetrieveUniqueSymptoms();
    }
}
