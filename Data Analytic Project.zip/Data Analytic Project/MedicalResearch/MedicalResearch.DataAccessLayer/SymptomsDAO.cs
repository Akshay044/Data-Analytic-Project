﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MedicalResearch.Entities;
using MedicalResearch.Utilities;
using System.Data.SqlClient;

namespace MedicalResearch.DataAccessLayer
{
   public class SymptomsDAO : ISymptomsDAO
    {
        public bool AddSymptomToDisease(SymptomDetails symptomDetails)
        {
            bool symptomAddedStatus = false;
            SymptomsDetail symptomDetailsTblData;
            try
            {
                symptomDetailsTblData = ConvertSymptomDetailEntityToTable(symptomDetails);
                using (MedicalResearchEntities medicalResearchDB = new MedicalResearchEntities())
                {

                    if (medicalResearchDB != null)
                    {
                        medicalResearchDB.AddToSymptomsDetails(symptomDetailsTblData);
                        medicalResearchDB.SaveChanges();
                        symptomAddedStatus = true;
                    }
                    else
                    {
                        symptomAddedStatus = false;
                        throw new MedicalResearchDALException("No tables found in the Medical Research database");

                    }


                }

                return symptomAddedStatus;

            }
            catch (MedicalResearchDALException dalEx)
            {

                throw dalEx;


            }

            catch (SqlException sqlEx)
            {
                MedicalResearchDALException dalEx = new MedicalResearchDALException(sqlEx.Message, sqlEx.InnerException);
                throw dalEx;


            }
            catch (Exception ex)
            {

                MedicalResearchDALException Dalex = new MedicalResearchDALException(ex.Message, ex.InnerException);
                throw Dalex;

            }
        }

        public List<string> RetrieveUniqueSymptoms()
        {
            List<string> symptoms=null;
            try
            {
                using (MedicalResearchEntities medicalResearchDB = new MedicalResearchEntities())
                {
                   
                     symptoms = (from symptom in medicalResearchDB.SymptomsDetails select symptom.SymptomName).Distinct().ToList<string>();

                }

                return symptoms;
            }
            catch (MedicalResearchDALException dalEx)
            {

                throw dalEx;


            }

            catch (SqlException sqlEx)
            {
                MedicalResearchDALException dalEx = new MedicalResearchDALException(sqlEx.Message, sqlEx.InnerException);
                throw dalEx;


            }
            catch (Exception ex)
            {

                MedicalResearchDALException Dalex = new MedicalResearchDALException(ex.Message, ex.InnerException);
                throw Dalex;

            }


        }

        #region Helper Methods

        private SymptomsDetail ConvertSymptomDetailEntityToTable(SymptomDetails symptomDetails)
        {
            SymptomsDetail symptomDetailsTbl = new SymptomsDetail()
            {
              DiseaseId=symptomDetails.DiseaseId,
              SymptomName=symptomDetails.SymptomName,
              Description=symptomDetails.Description,
             
            };
            return symptomDetailsTbl;
        }


        private SymptomDetails ConvertSymptomDetailEntityToTable(SymptomsDetail symptomDetailsTbl)
        {
            SymptomDetails symptomDetails = new SymptomDetails()
            {
                DiseaseId = symptomDetailsTbl.DiseaseId,
                SymptomName = symptomDetailsTbl.SymptomName,
                Description = symptomDetailsTbl.Description,

            };
            return symptomDetails;
        }

        #endregion


     
    }
}
